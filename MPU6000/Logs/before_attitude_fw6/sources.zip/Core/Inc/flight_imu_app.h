#ifndef FLIGHT_IMU_APP_H
#define FLIGHT_IMU_APP_H

#include "mpu6000.h"
#include "imu_telemetry.h"
#include "mpu6000_port.h"

/* Debugger snapshots, written only by the foreground. The control loop should
 * consume queued samples, not use these asynchronously as an estimator input. */
extern volatile MPU6000_Sample g_imu_sample;
extern volatile MPU6000_Measurement g_imu_measurement;
extern volatile MPU6000_Status g_imu_status;
extern volatile ImuTelemetryStats g_telemetry_status;
extern volatile uint32_t g_imu_sample_valid;
/* 1=main, 2=HAL ready, 3=clock ready, 4=peripherals ready, 5=app ready, 6=loop */
extern volatile uint32_t g_app_boot_stage;
/* HAL_OK=0; 0xFFFFFFFF means the FireWater boot UART check has not run. */
extern volatile uint32_t g_boot_uart_result;
extern volatile MPU6000_BusProbe g_sensor_bus_probe;

void FlightImuApp_Init(void);
void FlightImuApp_Service(void);
#endif
