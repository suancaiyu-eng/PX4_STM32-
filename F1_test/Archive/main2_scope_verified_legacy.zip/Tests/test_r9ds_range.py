"""Test calibration safeguards/normalization using synthetic test data only."""
from pathlib import Path
import contextlib
import copy
import importlib.util
import io
import json
import struct
import subprocess
import tempfile

ROOT = Path(__file__).resolve().parents[1]
spec = importlib.util.spec_from_file_location("r9ds_range", ROOT / "Tools/r9ds_range.py")
tool = importlib.util.module_from_spec(spec)
spec.loader.exec_module(tool)
payload = struct.pack("<4B9I10H", 1, 1, 3, 10, 1000, 5, 100, 0, 0, 0, 0, 0, 0, *([1000] * 10))
record = tool.packet(payload, 1)
assert record["valid"] and record["channels"] == [1000] * 10
for bad in (b"", bytes([2]) + payload[1:], payload[:40] + struct.pack("<H", 2048) + payload[42:]):
    try:
        tool.packet(bad)
        raise AssertionError("bad payload accepted")
    except ValueError:
        pass
with tempfile.TemporaryDirectory() as temporary:
    temp = Path(temporary)
    tool.ROOT = temp
    (temp / "Core/Inc").mkdir(parents=True)
    def samples(values):
        rows = []
        for index, channels in enumerate(values):
            row = copy.deepcopy(record)
            row.update(channels=channels, sequence=index+1, frame_count=100+index*5, last_frame_ms=1000+index*50)
            rows.append(row)
        return rows
    with contextlib.redirect_stdout(io.StringIO()):
        neutral = temp / "neutral.json"
        tool.analyze(samples([[1000]*10 for _ in range(30)]), "neutral", neutral, neutral, False)
        values = [[200,300]+[1000]*8]*20 + [[1000]*10]*20 + [[1800,1700]+[1000]*8]*20
        report = tool.analyze(samples(values), "range", neutral, temp / "range.json", True)
        assert report["valid_mask"] == 3
        assert report["channels"][0]["min"] == 200 and report["channels"][0]["max"] == 1800
        assert not report["channels"][2]["calibrated"]
        assert "0x0003U" in (temp / "Core/Inc/r9ds_calibration_data.h").read_text()
        invalid = samples(values)
        for row in invalid:
            row.update(valid=False, status="NO_DATA")
        try:
            tool.analyze(invalid, "range", neutral, temp / "bad.json", False)
            raise AssertionError("no-data calibration accepted")
        except RuntimeError:
            pass
    (temp / "harness.c").write_text(r'''
#include "r9ds_calibration.h"
#include <assert.h>
#include <stdio.h>
int main(void) {
    uint16_t raw[10] = {0};
    r9ds_normalized_t output;
    int previous=-1001;
    unsigned i;
    for(i=0;i<=2047;i++) {
        raw[0]=(uint16_t)i;
        R9DS_Normalize(raw,1,&output);
        assert(output.valid_mask==3 && output.configured_mask==3);
        assert(output.channel[0]>=-1000 && output.channel[0]<=1000);
        assert(output.channel[0]>=previous); previous=output.channel[0];
        assert(output.channel[2]==0);
    }
    raw[0]=200; R9DS_Normalize(raw,1,&output); assert(output.channel[0]==-1000);
    raw[0]=1000; R9DS_Normalize(raw,1,&output); assert(output.channel[0]==0);
    raw[0]=1800; R9DS_Normalize(raw,1,&output); assert(output.channel[0]==1000);
    raw[1]=650; R9DS_Normalize(raw,1,&output); assert(output.channel[1]==-500);
    raw[1]=1350; R9DS_Normalize(raw,1,&output); assert(output.channel[1]==500);
    R9DS_Normalize(raw,0,&output); assert(output.valid_mask==0 && output.channel[0]==0);
    puts("PASS: calibrated endpoints, asymmetric scaling, monotonic 11-bit input, clamping and invalid-state masks");
    return 0;
}
''')
    executable = temp / "test.exe"
    subprocess.run([r"D:\Users\21144\w64devkit\bin\gcc.exe", "-std=c99", "-Wall", "-Wextra", "-Werror",
                    "-I"+str(temp / "Core/Inc"), "-I"+str(ROOT / "Core/Inc"),
                    str(ROOT / "Core/Src/r9ds_calibration.c"), str(temp / "harness.c"), "-o", str(executable)], check=True)
    subprocess.run([str(executable)], check=True)
print("PASS: RC payload validation, measured range/header generation, no-data refusal and unmoved-channel invalidation")
